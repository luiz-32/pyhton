n1=2
n2=3
r= n1+n2
print(r)
r= n1-n2
print(r)
r=n1*n2
print(r)
r=n1/n2
print(r)
r=pow(n1,2)
print(r)
r=n1%2
print(r)
r=pow(n1,1/2)