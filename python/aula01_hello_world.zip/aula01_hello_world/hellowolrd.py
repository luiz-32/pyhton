nome= input("digite seu nome ")
print("hello world", nome )