const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startButton = document.getElementById('startButton');
const snakeColorSelector = document.getElementById('snakeColor'); // Seletor de cor

const unitSize = 20;
canvas.width = 600;
canvas.height = 500;

let snake = [{ x: 200, y: 200 }];
let food = { x: 100, y: 100 };
let dx = unitSize;
let dy = 0;
let score = 0;
let gameStarted = false; // Controle de estado do jogo
let snakeColor = 'royalblue'; // Cor da cobra

// Função para desenhar a cobra
function drawSnake() {
    ctx.fillStyle = snakeColor; // Usar a cor da cobra
    snake.forEach(part => {
        ctx.fillRect(part.x, part.y, unitSize, unitSize);
        ctx.strokeStyle = 'indigo';
        ctx.lineWidth = 2;
        ctx.strokeRect(part.x, part.y, unitSize, unitSize);
    });
}

// Função para desenhar a comida
function drawFood() {
    ctx.fillStyle = 'red';
    ctx.fillRect(food.x, food.y, unitSize, unitSize);
    ctx.strokeStyle = 'darkgreen';
    ctx.lineWidth = 2;
    ctx.strokeRect(food.x, food.y, unitSize, unitSize);
}

// Função de movimentação da cobra
function moveSnake() {
    const head = { x: snake[0].x + dx, y: snake[0].y + dy };
    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        generateFood();
        score += 10;
    } else {
        snake.pop();
    }
}

// Função para verificar colisões
function checkCollision() {
    if (
        snake[0].x < 0 ||
        snake[0].x >= canvas.width ||
        snake[0].y < 0 ||
        snake[0].y >= canvas.height
    ) {
        return true;
    }

    for (let i = 1; i < snake.length; i++) {
        if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) {
            return true;
        }
    }
    return false;
}

// Função para gerar a comida em posições aleatórias
function generateFood() {
    food.x = Math.floor(Math.random() * (canvas.width / unitSize)) * unitSize;
    food.y = Math.floor(Math.random() * (canvas.height / unitSize)) * unitSize;
}

// Função para mudar a direção da cobra
document.addEventListener('keydown', (event) => {
    if (event.key === 'w' && dy === 0) {
        dx = 0;
        dy = -unitSize;
    } else if (event.key === 's' && dy === 0) {
        dx = 0;
        dy = unitSize;
    } else if (event.key === 'a' && dx === 0) {
        dx = -unitSize;
        dy = 0;
    } else if (event.key === 'd' && dx === 0) {
        dx = unitSize;
        dy = 0;
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowUp' && dy === 0) {
        dx = 0;
        dy = -unitSize;
    } else if (event.key === 'ArrowDown' && dy === 0) {
        dx = 0;
        dy = unitSize;
    } else if (event.key === 'ArrowLeft' && dx === 0) {
        dx = -unitSize;
        dy = 0;
    } else if (event.key === 'ArrowRight' && dx === 0) {
        dx = unitSize;
        dy = 0;
    }
});

// Função para iniciar o jogo
function startGame() {
    gameStarted = true; // Marca o jogo como iniciado
    startButton.style.display = 'none'; // Esconde o botão de iniciar
    snakeColorSelector.style.display = 'none'; // Esconde o seletor de cor
    gameLoop(); // Inicia o loop do jogo
}

// Evento para iniciar o jogo ao pressionar Enter
document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !gameStarted) { // Se o jogo não foi iniciado
        startGame(); // Inicia o jogo
    }
});

// Evento do botão de iniciar o jogo
startButton.addEventListener('click', startGame);

// Loop principal do jogo
function gameLoop() {
    if (checkCollision()) {
        alert('Game Over!');
        document.location.reload(); // Reinicia o jogo
        return;
    }

    setTimeout(() => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Exibe o score
        ctx.fillStyle = 'white';
        ctx.font = '20px Arial';
        ctx.fillText('Score: ' + score, 10, 30);

        drawFood();
        moveSnake();
        drawSnake();
        gameLoop(); // Continua o loop
    }, 100);
}

// Atualiza a cor da cobra com base no seletor
snakeColorSelector.addEventListener('change', (event) => {
    snakeColor = event.target.value; // Muda a cor da cobra com base na seleção
});

generateFood();
